#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智谱AI 语音克隆 Web 应用
跨平台本地服务，支持 Windows 和 Mac
"""

import os
import sys
import time
import requests
from flask import Flask, render_template_string, request, jsonify, send_from_directory
import webbrowser
import threading

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

app = Flask(__name__)

API_BASE_URL = 'https://open.bigmodel.cn/api'
SYSTEM_VOICES = ['tongtong', 'chuichui', 'xiaochen', 'jam', 'kazi', 'douji', 'luodo']

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.abspath(os.path.join(BASE_DIR, 'outputs'))
VOICE_IDS_FILE = os.path.join(BASE_DIR, 'voice_ids.txt')

if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

def save_voice_id(voice_id, voice_name):
    """保存音色ID到文件"""
    try:
        with open(VOICE_IDS_FILE, 'a', encoding='utf-8') as f:
            f.write(f'{time.strftime("%Y-%m-%d %H:%M:%S")} | 音色名称: {voice_name} | 音色ID: {voice_id}\n')
    except Exception as e:
        print(f'保存音色ID失败: {str(e)}')

def load_voice_ids():
    """加载已保存的音色ID"""
    try:
        if not os.path.exists(VOICE_IDS_FILE):
            return []
        with open(VOICE_IDS_FILE, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        return [line.strip() for line in lines]
    except Exception as e:
        print(f'加载音色ID失败: {str(e)}')
        return []

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>智谱AI 语音克隆 - 本地服务</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            max-width: 900px;
            margin: 20px auto;
            padding: 0 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
            font-size: 28px;
        }
        h2 {
            color: #555;
            margin-bottom: 15px;
            font-size: 20px;
            border-bottom: 2px solid #4CAF50;
            padding-bottom: 8px;
        }
        .section {
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #666;
            font-weight: 500;
        }
        input[type="text"], textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        textarea {
            resize: vertical;
            min-height: 80px;
        }
        button {
            background: #4CAF50;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s;
        }
        button:hover:not(:disabled) {
            background: #45a049;
        }
        button:disabled {
            background: #cccccc;
            cursor: not-allowed;
        }
        .audio-player {
            margin-top: 15px;
            width: 100%;
        }
        .message {
            margin-top: 10px;
            padding: 10px;
            border-radius: 5px;
            display: none;
        }
        .message.error {
            background: #ffebee;
            color: #c62828;
            border: 1px solid #ef5350;
            display: block;
        }
        .message.success {
            background: #e8f5e9;
            color: #2e7d32;
            border: 1px solid #66bb6a;
            display: block;
        }
        .message.info {
            background: #e3f2fd;
            color: #1565c0;
            border: 1px solid #42a5f5;
            display: block;
        }
        .tip {
            color: #888;
            font-size: 13px;
            margin-top: 5px;
        }
        .mode-switch {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
        }
        .mode-btn {
            padding: 8px 16px;
            background: #e0e0e0;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .mode-btn.active {
            background: #4CAF50;
            color: white;
        }
        .voice-id-list {
            max-height: 200px;
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 10px;
            background: #fafafa;
        }
        .voice-id-item {
            padding: 8px;
            border-bottom: 1px solid #eee;
            cursor: pointer;
            transition: background 0.2s;
        }
        .voice-id-item:hover {
            background: #e8f5e9;
        }
        .voice-id-item:last-child {
            border-bottom: none;
        }
        .voice-id-copy {
            float: right;
            font-size: 12px;
            color: #4CAF50;
            cursor: pointer;
        }
        .voice-id-copy:hover {
            text-decoration: underline;
        }
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .modal-overlay.show {
            display: flex;
        }
        .modal-content {
            background: white;
            padding: 25px;
            border-radius: 10px;
            min-width: 400px;
            max-width: 90%;
            max-height: 80%;
            overflow-y: auto;
        }
        .modal-content h3 {
            margin-top: 0;
            margin-bottom: 20px;
            color: #333;
        }
        .modal-close {
            float: right;
            cursor: pointer;
            font-size: 20px;
            color: #999;
        }
        .modal-close:hover {
            color: #333;
        }
        .voice-id-display {
            font-family: monospace;
            background: #f5f5f5;
            padding: 15px;
            border-radius: 5px;
            word-break: break-all;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎤 智谱AI 语音克隆 - 本地服务</h1>

        <div class="section">
            <h2>1. API Key 配置</h2>
            <div class="form-group">
                <label for="apiKey">API Key</label>
                <input type="text" id="apiKey" placeholder="填写你的API Key，无API Key可跳过，仅使用系统语音">
            </div>
            <p class="tip">获取API Key请访问：https://open.bigmodel.cn/</p>
        </div>

        <div class="section">
            <h2>2. 文生音频</h2>
            <div class="mode-switch">
                <button class="mode-btn active" id="modeApi" onclick="setMode('api')">API生成（需API Key）</button>
                <button class="mode-btn" id="modeSystem" onclick="setMode('system')">系统语音（无需API Key）</button>
            </div>
            <div class="form-group">
                <label for="ttsText">输入文本</label>
                <textarea id="ttsText" placeholder="请输入要转换为语音的文本内容"></textarea>
            </div>
            <div class="form-group" id="voiceSelectGroup" style="display:none;">
                <label for="voiceSelect">选择系统音色</label>
                <select id="voiceSelect" style="width:100%;padding:10px;border:1px solid #ddd;border-radius:5px;">
                    {% for voice in system_voices %}
                    <option value="{{ voice }}">{{ voice }}</option>
                    {% endfor %}
                </select>
            </div>
            <button onclick="generateTTS()">生成音频</button>
            <audio id="ttsPlayer" class="audio-player" controls style="display:none;">
            <div id="ttsMessage" class="message"></div>
        </div>

        <div class="section">
            <h2>3. 使用已有音色ID生成TTS</h2>
            <div class="form-group">
                <label for="customVoiceId">音色ID</label>
                <input type="text" id="customVoiceId" placeholder="请输入音色ID">
                <button onclick="loadVoiceIds()" style="margin-top: 5px;">📋 加载已保存的音色ID</button>
            </div>
            <div class="form-group">
                <label for="customTtsText">输入文本</label>
                <textarea id="customTtsText" placeholder="请输入要转换为语音的文本内容"></textarea>
            </div>
            <button id="customTtsBtn" onclick="generateCustomTTS()" disabled>请填写API Key后使用</button>
            <audio id="customTtsPlayer" class="audio-player" controls style="display:none;">
            <div id="customTtsMessage" class="message"></div>
            
            <div class="form-group">
                <label>已保存的音色ID列表</label>
                <div id="voiceIdList" class="voice-id-list"></div>
            </div>
        </div>

        <div class="section">
            <h2>4. 语音克隆</h2>
            <div class="form-group">
                <label for="cloneAudio">上传参考音频</label>
                <input type="file" id="cloneAudio" accept=".wav,.mp3,.m4a,.ogg,.flac">
            </div>
            <div class="form-group">
                <label for="cloneText">输入生成文本</label>
                <textarea id="cloneText" placeholder="请输入要生成的文本内容"></textarea>
            </div>
            <div class="form-group">
                <label for="sampleText">参考音频对应文本（选填，推荐填写以获得更好效果）</label>
                <textarea id="sampleText" placeholder="请输入参考音频对应的文本内容"></textarea>
            </div>
            <button id="cloneBtn" onclick="cloneVoice()" disabled>请填写API Key后使用</button>
            <audio id="clonePlayer" class="audio-player" controls style="display:none;">
            <div id="cloneMessage" class="message"></div>
        </div>
    </div>

    <div id="voiceIdModal" class="modal-overlay">
        <div class="modal-content">
            <span class="modal-close" onclick="closeModal()">&times;</span>
            <h3>🎉 音色复刻成功！</h3>
            <p>您的音色ID已生成，请妥善保存：</p>
            <div class="voice-id-display" id="newVoiceId"></div>
            <p class="tip" style="margin-top: 15px;">点击音色ID即可复制</p>
            <button onclick="closeModal()" style="margin-top: 15px;">关闭</button>
        </div>
    </div>

    <script>
        let currentMode = 'api';

        document.getElementById('apiKey').addEventListener('input', function() {
            const apiKey = this.value.trim();
            const cloneBtn = document.getElementById('cloneBtn');
            const customTtsBtn = document.getElementById('customTtsBtn');
            if (apiKey) {
                cloneBtn.disabled = false;
                cloneBtn.textContent = '开始克隆';
                customTtsBtn.disabled = false;
                customTtsBtn.textContent = '生成音频';
            } else {
                cloneBtn.disabled = true;
                cloneBtn.textContent = '请填写API Key后使用';
                customTtsBtn.disabled = true;
                customTtsBtn.textContent = '请填写API Key后使用';
            }
        });

        function setMode(mode) {
            currentMode = mode;
            document.getElementById('modeApi').classList.remove('active');
            document.getElementById('modeSystem').classList.remove('active');
            document.getElementById('mode' + mode.charAt(0).toUpperCase() + mode.slice(1)).classList.add('active');
            document.getElementById('voiceSelectGroup').style.display = mode === 'system' ? 'block' : 'none';
        }

        function showMessage(elementId, type, text) {
            const el = document.getElementById(elementId);
            el.className = 'message ' + type;
            el.textContent = text;
        }

        function getApiKey() {
            return document.getElementById('apiKey').value.trim();
        }

        function buildHeaders() {
            const headers = { 'Content-Type': 'application/json' };
            const apiKey = getApiKey();
            if (apiKey) {
                headers['Authorization'] = 'Bearer ' + apiKey;
            }
            return headers;
        }

        async function generateTTS() {
            const text = document.getElementById('ttsText').value.trim();
            if (!text) {
                showMessage('ttsMessage', 'error', '请输入要转换的文本');
                return;
            }

            const apiKey = getApiKey();
            const data = { text: text };

            if (currentMode === 'system') {
                data.mode = 'system';
                data.voice_id = document.getElementById('voiceSelect').value;
            } else {
                if (!apiKey) {
                    showMessage('ttsMessage', 'error', 'API生成模式需要填写API Key，或切换到系统语音模式');
                    return;
                }
                data.mode = 'api';
            }

            showMessage('ttsMessage', 'info', '正在生成音频...');

            try {
                const response = await fetch('/api/tts', {
                    method: 'POST',
                    headers: buildHeaders(),
                    body: JSON.stringify(data)
                });

                const result = await response.json();

                if (result.success) {
                    showMessage('ttsMessage', 'success', '音频生成成功！');
                    const player = document.getElementById('ttsPlayer');
                    player.src = '/api/outputs/' + result.filename;
                    player.style.display = 'block';
                    player.play();
                } else {
                    showMessage('ttsMessage', 'error', '生成失败：' + result.error);
                }
            } catch (e) {
                showMessage('ttsMessage', 'error', '请求失败：' + e.message);
            }
        }

        async function cloneVoice() {
            const apiKey = getApiKey();
            const audioFile = document.getElementById('cloneAudio').files[0];
            const text = document.getElementById('cloneText').value.trim();
            const sampleText = document.getElementById('sampleText').value.trim();

            if (!apiKey) {
                showMessage('cloneMessage', 'error', '请先填写API Key');
                return;
            }

            if (!audioFile) {
                showMessage('cloneMessage', 'error', '请上传参考音频');
                return;
            }

            if (!text) {
                showMessage('cloneMessage', 'error', '请输入生成文本');
                return;
            }

            const formData = new FormData();
            formData.append('text', text);
            if (sampleText) {
                formData.append('sample_text', sampleText);
            }

            showMessage('cloneMessage', 'info', '正在处理...这可能需要一点时间');

            try {
                const response = await fetch('/api/clone', {
                    method: 'POST',
                    headers: {
                        'Authorization': 'Bearer ' + apiKey
                    },
                    body: formData
                });

                const result = await response.json();

                if (result.success) {
                    showMessage('cloneMessage', 'success', '语音克隆成功！');
                    const player = document.getElementById('clonePlayer');
                    player.src = '/api/outputs/' + result.filename;
                    player.style.display = 'block';
                    player.play();
                    
                    if (result.voice_id) {
                        showVoiceIdModal(result.voice_id);
                    }
                } else {
                    showMessage('cloneMessage', 'error', '克隆失败：' + result.error);
                }
            } catch (e) {
                showMessage('cloneMessage', 'error', '请求失败：' + e.message);
            }
        }

        async function generateCustomTTS() {
            const voiceId = document.getElementById('customVoiceId').value.trim();
            const text = document.getElementById('customTtsText').value.trim();
            const apiKey = getApiKey();

            if (!voiceId) {
                showMessage('customTtsMessage', 'error', '请输入音色ID');
                return;
            }

            if (!text) {
                showMessage('customTtsMessage', 'error', '请输入要转换的文本');
                return;
            }

            if (!apiKey) {
                showMessage('customTtsMessage', 'error', '请先填写API Key');
                return;
            }

            showMessage('customTtsMessage', 'info', '正在生成音频...');

            try {
                const response = await fetch('/api/tts-custom', {
                    method: 'POST',
                    headers: buildHeaders(),
                    body: JSON.stringify({ voice_id: voiceId, text: text })
                });

                const result = await response.json();

                if (result.success) {
                    showMessage('customTtsMessage', 'success', '音频生成成功！');
                    const player = document.getElementById('customTtsPlayer');
                    player.src = '/api/outputs/' + result.filename;
                    player.style.display = 'block';
                    player.play();
                } else {
                    showMessage('customTtsMessage', 'error', '生成失败：' + result.error);
                }
            } catch (e) {
                showMessage('customTtsMessage', 'error', '请求失败：' + e.message);
            }
        }

        async function loadVoiceIds() {
            try {
                const response = await fetch('/api/voice-ids');
                const result = await response.json();

                const list = document.getElementById('voiceIdList');
                if (result.success && result.voice_ids.length > 0) {
                    list.innerHTML = result.voice_ids.map((item, index) => {
                        return `<div class="voice-id-item" onclick="selectVoiceId('${item.voice_id}')">
                            ${item.name || '未命名音色'} - ${item.voice_id}
                            <span class="voice-id-copy" onclick="copyVoiceId('${item.voice_id}', event)">复制</span>
                        </div>`;
                    }).join('');
                } else {
                    list.innerHTML = '<p style="color: #888;">暂无保存的音色ID</p>';
                }
            } catch (e) {
                console.error('加载音色ID失败:', e);
            }
        }

        function selectVoiceId(voiceId) {
            document.getElementById('customVoiceId').value = voiceId;
        }

        async function copyVoiceId(voiceId, event) {
            event.stopPropagation();
            try {
                await navigator.clipboard.writeText(voiceId);
                alert('音色ID已复制到剪贴板');
            } catch (e) {
                alert('复制失败，请手动复制');
            }
        }

        function showVoiceIdModal(voiceId) {
            document.getElementById('newVoiceId').textContent = voiceId;
            document.getElementById('voiceIdModal').classList.add('show');
        }

        function closeModal() {
            document.getElementById('voiceIdModal').classList.remove('show');
        }

        document.getElementById('newVoiceId').addEventListener('click', async function() {
            const voiceId = this.textContent;
            try {
                await navigator.clipboard.writeText(voiceId);
                alert('音色ID已复制到剪贴板');
            } catch (e) {
                alert('复制失败，请手动复制');
            }
        });
    </script>
</body>
</html>
"""

@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
    return response

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE, system_voices=SYSTEM_VOICES)

@app.route('/api/outputs/<filename>')
def serve_output(filename):
    return send_from_directory(OUTPUT_DIR, filename)

def generate_local_tts(text, voice_id):
    import subprocess
    filename = f'tts_{int(time.time())}.wav'
    filepath = os.path.join(OUTPUT_DIR, filename)
    
    if sys.platform == 'darwin':
        voice_map = {
            'tongtong': 'Tingting',
            'chuichui': 'Samantha',
            'xiaochen': 'Sinji',
            'jam': 'Alex',
            'kazi': 'Kathy',
            'douji': 'Tom',
            'luodo': 'Meijia'
        }
        voice = voice_map.get(voice_id, 'Tingting')
        try:
            aiff_path = filepath.replace('.wav', '.aiff')
            subprocess.run(['say', '-v', voice, '-o', aiff_path, text], 
                         check=True, capture_output=True)
            subprocess.run(['afconvert', '-f', 'WAVE', '-d', 'LEI16@22050', aiff_path, filepath],
                         check=True, capture_output=True)
            os.remove(aiff_path)
            return filename
        except subprocess.CalledProcessError as e:
            raise Exception(f'系统语音生成失败: {e.stderr.decode("utf-8", errors="ignore")}')
    elif sys.platform == 'win32':
        try:
            try:
                import win32com.client
                speaker = win32com.client.Dispatch("SAPI.SpVoice")
                stream = win32com.client.Dispatch("SAPI.SpFileStream")
                stream.Open(filepath, 3)
                speaker.AudioOutputStream = stream
                speaker.Speak(text)
                stream.Close()
                return filename
            except ImportError:
                ps_script = f"""
                Add-Type -AssemblyName System.Speech
                $speaker = New-Object System.Speech.Synthesis.SpeechSynthesizer
                $speaker.SetOutputToWaveFile('{filepath}')
                $speaker.Speak('{text.replace("'", "''")}')
                $speaker.Dispose()
                """
                result = subprocess.run(['powershell', '-Command', ps_script], 
                                     capture_output=True, text=True)
                if result.returncode != 0:
                    raise Exception(f'PowerShell错误: {result.stderr}')
                return filename
        except Exception as e:
            raise Exception(f'系统语音生成失败: {str(e)}')
    else:
        raise Exception(f'不支持的操作系统: {sys.platform}')

@app.route('/api/tts', methods=['POST', 'OPTIONS'])
def generate_tts():
    if request.method == 'OPTIONS':
        return '', 200

    try:
        auth_header = request.headers.get('Authorization', '')
        api_key = ''
        if auth_header.startswith('Bearer '):
            api_key = auth_header[7:]
        elif auth_header:
            api_key = auth_header

        data = request.get_json()
        text = data.get('text', '')
        mode = data.get('mode', 'api')

        if mode == 'system':
            voice_id = data.get('voice_id', 'tongtong')
            filename = generate_local_tts(text, voice_id)
            return jsonify({'success': True, 'filename': filename})
        else:
            if not api_key:
                return jsonify({'success': False, 'error': 'API生成模式需要填写API Key，或切换到系统语音模式'})
            url = f'{API_BASE_URL}/paas/v4/audio/speech'
            params = {
                'model': 'glm-tts',
                'input': text,
                'voice': 'tongtong',
                'response_format': 'wav',
                'speed': 1.0,
                'volume': 1.0
            }
            headers = {'Authorization': f'Bearer {api_key}', 'Content-Type': 'application/json'}

            response = requests.post(url, headers=headers, json=params)

            if response.status_code == 200:
                filename = f'tts_{int(time.time())}.wav'
                filepath = os.path.join(OUTPUT_DIR, filename)
                with open(filepath, 'wb') as f:
                    f.write(response.content)
                return jsonify({'success': True, 'filename': filename})
            else:
                try:
                    error_msg = response.json().get('error', {}).get('message', str(response.status_code))
                except:
                    error_msg = f'HTTP {response.status_code}'
                return jsonify({'success': False, 'error': error_msg})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/clone', methods=['POST', 'OPTIONS'])
def clone_voice():
    if request.method == 'OPTIONS':
        return '', 200

    try:
        auth_header = request.headers.get('Authorization', '')
        api_key = ''
        if auth_header.startswith('Bearer '):
            api_key = auth_header[7:]
        elif auth_header:
            api_key = auth_header

        if not api_key:
            return jsonify({'success': False, 'error': '请先填写API Key'})

        text = request.form.get('text', '')
        sample_text = request.form.get('sample_text', '')
        audio_file = request.files.get('audio')

        if not text or not audio_file:
            return jsonify({'success': False, 'error': '参数不完整'})

        temp_audio_path = os.path.join(OUTPUT_DIR, f'temp_{int(time.time())}_{audio_file.filename}')
        audio_file.save(temp_audio_path)

        headers = {'Authorization': f'Bearer {api_key}'}
        upload_url = f'{API_BASE_URL}/paas/v4/files'
        files = {'file': open(temp_audio_path, 'rb')}
        upload_data = {'purpose': 'voice-clone-input'}

        upload_response = requests.post(upload_url, headers=headers, files=files, data=upload_data)
        upload_response.raise_for_status()
        file_id = upload_response.json()['id']

        clone_url = f'{API_BASE_URL}/paas/v4/voice/clone'
        voice_name = f'voice_{int(time.time())}'
        clone_params = {
            'model': 'glm-tts-clone',
            'voice_name': voice_name,
            'input': text,
            'file_id': file_id,
            'request_id': f'req_{int(time.time())}'
        }

        if sample_text:
            clone_params['text'] = sample_text

        clone_response = requests.post(clone_url, headers={**headers, 'Content-Type': 'application/json'}, json=clone_params)
        clone_response.raise_for_status()
        clone_result = clone_response.json()

        preview_file_id = clone_result['file_id']
        download_url = f'{API_BASE_URL}/paas/v4/files/{preview_file_id}/content'
        download_response = requests.get(download_url, headers=headers)
        download_response.raise_for_status()

        filename = f'clone_{int(time.time())}.wav'
        filepath = os.path.join(OUTPUT_DIR, filename)
        with open(filepath, 'wb') as f:
            f.write(download_response.content)

        if os.path.exists(temp_audio_path):
            os.remove(temp_audio_path)

        voice_id = clone_result.get('voice', '')
        if voice_id:
            save_voice_id(voice_id, voice_name)

        return jsonify({'success': True, 'filename': filename, 'voice_id': voice_id})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/tts-custom', methods=['POST', 'OPTIONS'])
def generate_tts_custom():
    if request.method == 'OPTIONS':
        return '', 200

    try:
        auth_header = request.headers.get('Authorization', '')
        api_key = ''
        if auth_header.startswith('Bearer '):
            api_key = auth_header[7:]
        elif auth_header:
            api_key = auth_header

        if not api_key:
            return jsonify({'success': False, 'error': '请先填写API Key'})

        data = request.get_json()
        text = data.get('text', '')
        voice_id = data.get('voice_id', '')

        if not text:
            return jsonify({'success': False, 'error': '请输入要转换的文本'})

        if not voice_id:
            return jsonify({'success': False, 'error': '请输入音色ID'})

        url = f'{API_BASE_URL}/paas/v4/audio/speech'
        params = {
            'model': 'glm-tts',
            'input': text,
            'voice': voice_id,
            'response_format': 'wav',
            'speed': 1.0,
            'volume': 1.0
        }
        headers = {'Authorization': f'Bearer {api_key}', 'Content-Type': 'application/json'}

        response = requests.post(url, headers=headers, json=params)

        if response.status_code == 200:
            filename = f'tts_custom_{int(time.time())}.wav'
            filepath = os.path.join(OUTPUT_DIR, filename)
            with open(filepath, 'wb') as f:
                f.write(response.content)
            return jsonify({'success': True, 'filename': filename})
        else:
            try:
                error_msg = response.json().get('error', {}).get('message', str(response.status_code))
            except:
                error_msg = f'HTTP {response.status_code}'
            return jsonify({'success': False, 'error': error_msg})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/voice-ids', methods=['GET'])
def get_voice_ids():
    try:
        voice_ids = load_voice_ids()
        parsed_voice_ids = []
        for line in voice_ids:
            parts = line.split(' | ')
            if len(parts) >= 3:
                name_part = parts[1].replace('音色名称: ', '')
                id_part = parts[2].replace('音色ID: ', '')
                parsed_voice_ids.append({
                    'name': name_part,
                    'voice_id': id_part,
                    'timestamp': parts[0]
                })
        return jsonify({'success': True, 'voice_ids': parsed_voice_ids})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

def open_browser():
    time.sleep(1.5)
    webbrowser.open('http://localhost:7860')

if __name__ == '__main__':
    print('='*60)
    print('🚀 智谱AI 语音克隆 Web 服务启动中...')
    print('='*60)
    print(f'📂 输出目录: {OUTPUT_DIR}')
    print(f'🌐 访问地址: http://localhost:7860')
    print('='*60)

    browser_thread = threading.Thread(target=open_browser)
    browser_thread.daemon = True
    browser_thread.start()

    app.run(host='0.0.0.0', port=7860, debug=False)
