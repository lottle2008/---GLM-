============================================================
              Zhipu AI Audio Clone - Usage Guide
============================================================

[Option 1] Run from Source Code (Recommended for testing)
------------------------------------------------------------
1. Install Python 3.7+ from https://www.python.org/downloads/
2. Install dependencies:
   pip install flask requests flask-cors
3. Double-click run.bat to start
4. Open browser: http://localhost:7860


[Option 2] Build Executable
------------------------------------------------------------
1. Install Python 3.7+ from https://www.python.org/downloads/
2. Double-click build.bat to build
3. Find output: dist\ZhipuAudio\ZhipuAudio.exe


[How to Use]
------------------------------------------------------------
1. System Voice Mode (No API Key needed):
   - Select "System Voice" tab
   - Choose voice type
   - Enter text and generate

2. API Mode (API Key required):
   - Get API Key from Zhipu AI console
   - Select "API Generation" tab
   - Enter API Key and text
   - Generate audio

3. Voice Clone (API Key required):
   - Get API Key from Zhipu AI console
   - Select "Voice Clone" tab
   - Upload reference audio file
   - Enter text to generate


[Common Issues]
------------------------------------------------------------
Q: "Python not found" error
A: Install Python and check "Add to PATH" during install

Q: Build fails
A: Run cmd as Administrator and try again

Q: Web interface shows "Failed to fetch"
A: Disable firewall or add exception for port 7860


============================================================
