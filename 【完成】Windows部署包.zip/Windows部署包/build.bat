@echo off
chcp 65001 >nul

cd /d "%~dp0"

echo [INFO] Checking Python installation...
python --version >nul 2>&1
if not errorlevel 1 goto :install_deps

echo [INFO] Python not found. Installing Python via winget...
echo.

winget install Python.Python.3.11 --accept-source-agreements --accept-package-agreements -h
if errorlevel 1 (
    echo.
    echo [WARNING] winget failed, trying alternative method...
    echo.
    echo Please manually install Python from:
    echo https://www.python.org/downloads/
    echo.
    echo Or search "Python" in Microsoft Store app.
    echo.
    pause
    exit /b 1
)

echo [OK] Python installed. Please run this script again.
pause
exit /b 0

:install_deps
echo [OK] Python detected
echo.

echo [INFO] Installing dependencies...
pip install flask requests flask-cors pyinstaller -q 2>nul
if errorlevel 1 (
    echo [INFO] Retrying with python -m pip...
    python -m pip install flask requests flask-cors pyinstaller -q 2>nul
)

echo [OK] Dependencies ready
echo.

echo [INFO] Building application...
pyinstaller --onedir --name ZhipuAudio --hidden-import flask --hidden-import flask_cors --hidden-import requests app.py --noconfirm --distpath .

echo.
echo [SUCCESS] Build complete!
echo Output: %~dp0ZhipuAudio\ZhipuAudio.exe
echo.
pause
exit /b 0
