@echo off
chcp 65001 >nul

echo Starting Zhipu Audio Clone Web Service...
echo Please open browser: http://localhost:7860
echo.

start http://localhost:7860
python app.py
